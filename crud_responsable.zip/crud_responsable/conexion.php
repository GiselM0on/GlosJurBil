<?php
$cn = mysqli_connect("localhost", "root", "", "terminos_1_33");

if (!$cn) {
    die("Error de conexión: " . mysqli_connect_error());
}
?>
