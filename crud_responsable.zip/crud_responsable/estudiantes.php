<?php
session_start();
include 'conexion.php'; // Aquí se crea $cn (mysqli)

// ---------------------------
// VALIDACIÓN DE ACCESO
// ---------------------------
if (!isset($_SESSION['rol']) || ($_SESSION['rol'] !== 'docente' && $_SESSION['rol'] !== 'administrador')) {
    header("Location: index.php"); // Tu proyecto NO tiene login.php
    exit();
}

// usuario actual
$current_user = [
    'id'  => $_SESSION['id_Usuario'] ?? 0,
    'rol' => $_SESSION['rol']
];

// ---------------------------
// ACCIONES POST (aprobar/rechazar)
// ---------------------------
if ($_POST && isset($_POST['accion'])) {

    $id_Termino = $_POST['id_Termino'];
    $accion     = $_POST['accion'];
    $comentario = $_POST['comentario'] ?? "";

    $estado_valid = ($accion === 'aprobar') ? 'aprobado' : 'rechazado';

    if ($accion === 'rechazar' && empty($comentario)) {
        echo "<script>alert('Comentario requerido para rechazar.');</script>";
        exit;
    }

    // REGISTRO DE VALIDACIÓN
    $sql_valid = "INSERT INTO gls_jur_bil_validacion 
        (comentario, estado_validacion, fecha_validacion, id_Termino, id_Usuario) 
        VALUES (?,?,?,?,NOW())";

    $stmt_valid = mysqli_prepare($cn, $sql_valid);
    mysqli_stmt_bind_param($stmt_valid, "ssii",
        $comentario,
        $estado_valid,
        $id_Termino,
        $current_user["id"]
    );
    mysqli_stmt_execute($stmt_valid);

    // ACTUALIZAR ESTADO DEL TÉRMINO
    $sql_update = "UPDATE gls_jur_bil_termino SET estado=?, fecha_modificacion=NOW() WHERE id_Termino=?";
    $stmt_update = mysqli_prepare($cn, $sql_update);
    mysqli_stmt_bind_param($stmt_update, "si", $estado_valid, $id_Termino);
    mysqli_stmt_execute($stmt_update);

    header("Location: estudiantes.php?seccion=revision_terminos");
    exit;
}

// ---------------------------
// LECTURA DE TÉRMINOS PENDIENTES
// ---------------------------
$sql = "SELECT t.id_Termino, t.ejemplo_aplicativo, t.referencia_bibliogr, t.fecha_creacion,
        tes.palabra AS espanol, tes.definicion AS def_es,
        ten.palabra AS ingles, ten.definicion AS def_en,
        u.nombre AS propuesto_por
        FROM gls_jur_bil_termino t
        JOIN gls_jur_bil_usuario u ON t.id_Usuario = u.id_Usuario
        LEFT JOIN gls_jur_bil_traduccion tes ON t.id_Termino = tes.id_Termino AND tes.id_Idioma = 1
        LEFT JOIN gls_jur_bil_traduccion ten ON t.id_Termino = ten.id_Termino AND ten.id_Idioma = 2
        WHERE t.estado = 'pendiente'
        ORDER BY t.fecha_creacion DESC";

$result = mysqli_query($cn, $sql);

$terms = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $terms[] = $row;
    }
}

// DEFINIR SECCIÓN
$seccion = $_GET["seccion"] ?? "revision_terminos";

?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Revisión Docente - Glosario Jurídico</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>

<body style="background:#f6f6f6;">

<div class="container mt-4">

<?php if ($seccion === "revision_terminos"): ?>

<h1 class="mb-4 text-center">Revisión de Términos</h1>

<?php if (empty($terms)): ?>
    <div class="alert alert-info">No hay términos pendientes.</div>
<?php else: ?>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Término (ES)</th>
            <th>Término (EN)</th>
            <th>Propuesto por</th>
            <th>Fecha</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>

    <?php foreach ($terms as $row): ?>
        <tr>
            <td>
                <b><?= htmlspecialchars($row['espanol']) ?></b><br>
                <small><?= htmlspecialchars($row['def_es']) ?></small>
            </td>

            <td>
                <b><?= htmlspecialchars($row['ingles']) ?></b><br>
                <small><?= htmlspecialchars($row['def_en']) ?></small>
            </td>

            <td><?= htmlspecialchars($row['propuesto_por']) ?></td>
            <td><?= date("d/m/Y", strtotime($row["fecha_creacion"])) ?></td>

            <td>
                <form method="POST" style="display:inline-block;">
                    <input type="hidden" name="id_Termino" value="<?= $row['id_Termino'] ?>">
                    <input type="hidden" name="accion" value="aprobar">
                    <button class="btn btn-success btn-sm">Aprobar</button>
                </form>

                <!-- Botón rechazar -->
                <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#rechazo<?= $row['id_Termino'] ?>">
                    Rechazar
                </button>
            </td>
        </tr>

        <!-- Modal rechazo -->
        <div class="modal fade" id="rechazo<?= $row['id_Termino'] ?>">
            <div class="modal-dialog">
                <form method="POST" class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title">Rechazar Término</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">
                        <p><b><?= $row['espanol'] ?></b> (<?= $row['ingles'] ?>)</p>

                        <textarea name="comentario" class="form-control" required 
                        placeholder="Motivo del rechazo"></textarea>

                        <input type="hidden" name="id_Termino" value="<?= $row['id_Termino'] ?>">
                        <input type="hidden" name="accion" value="rechazar">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button class="btn btn-danger">Rechazar</button>
                    </div>
                </form>
            </div>
        </div>

    <?php endforeach; ?>

    </tbody>
</table>

<?php endif; ?>

<?php else: ?>
    <div class="alert alert-danger">Sección no encontrada.</div>
<?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
