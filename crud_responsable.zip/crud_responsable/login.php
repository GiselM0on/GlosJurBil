<?php
session_start();
include 'conexion.php';

// Si ya está logueado, redirigir
if (isset($_SESSION['rol'])) {
    header("Location: index.php");
    exit();
}

// Si envió el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    // Consulta ejemplo (ajusta a tu BD real)
    $sql = "SELECT * FROM usuarios WHERE usuario = ?";
    $stmt = $cn->prepare($sql);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();

        if ($password === $row['password']) {
            $_SESSION['id_Usuario'] = $row['id_Usuario'];
            $_SESSION['rol'] = $row['rol'];

            header("Location: estudiantes.php");
            exit();
        }
    }

    $error = "Usuario o contraseña incorrectos.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Login</title>
</head>
<body>

<h2>Iniciar Sesión</h2>

<?php if (isset($error)) echo "<p style='color:red'>$error</p>"; ?>

<form method="POST">
    Usuario:<br>
    <input type="text" name="usuario" required><br><br>

    Contraseña:<br>
    <input type="password" name="password" required><br><br>

    <button type="submit">Ingresar</button>
</form>

</body>
</html>
